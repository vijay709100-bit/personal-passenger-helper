MOBILE COMPANION
1. Put this folder on a private HTTPS static host you control, or open index.html locally in a modern browser that supports Web Crypto.
2. On Android, open the page in a supported browser and use its menu > Add to Home screen.
3. This mobile copy stores its own encrypted vault on this device. It does not automatically sync with the PC extension.
4. To move profiles between devices: export the encrypted backup on one device, transfer the JSON file privately, then import it on the other device using the same passphrase.
5. Do not store IRCTC passwords, OTPs, Aadhaar numbers, card/bank details, or upload the backup to public storage.
