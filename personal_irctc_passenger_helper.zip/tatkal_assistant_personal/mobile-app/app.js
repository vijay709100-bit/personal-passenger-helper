const $=id=>document.getElementById(id);
let key=null, profiles={};
const enc=new TextEncoder(), dec=new TextDecoder();
function b64(bytes){return btoa(String.fromCharCode(...new Uint8Array(bytes)))}
function unb64(s){return Uint8Array.from(atob(s),c=>c.charCodeAt(0))}
async function derive(pass,salt){const material=await crypto.subtle.importKey("raw",enc.encode(pass),"PBKDF2",false,["deriveKey"]);return crypto.subtle.deriveKey({name:"PBKDF2",salt,iterations:250000,hash:"SHA-256"},material,{name:"AES-GCM",length:256},false,["encrypt","decrypt"])}
async function encrypt(obj,pass,salt){const iv=crypto.getRandomValues(new Uint8Array(12));const k=await derive(pass,salt);const ct=await crypto.subtle.encrypt({name:"AES-GCM",iv},k,enc.encode(JSON.stringify(obj)));return {salt:b64(salt),iv:b64(iv),data:b64(ct)}}
async function decrypt(blob,pass){const k=await derive(pass,unb64(blob.salt));const pt=await crypto.subtle.decrypt({name:"AES-GCM",iv:unb64(blob.iv)},k,unb64(blob.data));return JSON.parse(dec.decode(pt))}
async function persist(){const pass=$("passphrase").value;const old=await Promise.resolve({vault: JSON.parse(localStorage.getItem("vault")||"null")});const salt=old.vault?unb64(old.vault.salt):crypto.getRandomValues(new Uint8Array(16));const vault=await encrypt(profiles,pass,salt);await Promise.resolve(localStorage.setItem("vault", JSON.stringify(vault)))}
function refresh(){const sel=$("profiles");sel.innerHTML='<option value="">Select profile</option>';Object.keys(profiles).forEach(n=>{const o=document.createElement("option");o.value=n;o.textContent=n;sel.append(o)})}
function formData(){return {name:$("name").value.trim(),age:$("age").value,gender:$("gender").value,berth:$("berth").value}}
function fill(p){$("profileName").value=p.profileName||"";$("name").value=p.name||"";$("age").value=p.age||"";$("gender").value=p.gender||"";$("berth").value=p.berth||""}
function clear(){fill({})}
function renderCopies(){const p=formData();const items=[["Passenger name",p.name],["Age",p.age],["Gender",p.gender],["Berth preference",p.berth]];const root=$("copyButtons");root.innerHTML="";items.forEach(([label,value])=>{const b=document.createElement("button");b.textContent="Copy "+label;b.disabled=!value;b.onclick=async()=>{await navigator.clipboard.writeText(value);$("status").textContent=label+" copied. Paste and verify manually."};root.append(b)})}
$("unlock").onclick=async()=>{try{const pass=$("passphrase").value;if(pass.length<10)throw Error("Use a passphrase of at least 10 characters.");const saved=await Promise.resolve({vault: JSON.parse(localStorage.getItem("vault")||"null")});if(saved.vault){profiles=await decrypt(saved.vault,pass)}else{profiles={};await persist()}key=true;$("app").classList.remove("hidden");refresh();$("status").textContent="Vault unlocked. Data remains encrypted on this device."}catch(e){$("status").textContent="Could not unlock: "+e.message}};
$("lock").onclick=()=>{key=null;profiles={};$("app").classList.add("hidden");$("passphrase").value="";$("status").textContent="Vault locked."};
$("save").onclick=async()=>{if(!key)return;const n=$("profileName").value.trim();const p=formData();if(!n||!p.name||!p.age||!p.gender){$("status").textContent="Enter profile name, passenger name, age and gender.";return}profiles[n]=p;await persist();refresh();$("profiles").value=n;$("status").textContent="Profile saved in encrypted local vault."};
$("load").onclick=()=>{const n=$("profiles").value;if(n){fill({...profiles[n],profileName:n});renderCopies()}};
$("delete").onclick=async()=>{const n=$("profiles").value;if(n&&confirm("Delete profile "+n+"?")){delete profiles[n];await persist();refresh();clear()}};
$("clear").onclick=()=>{clear();renderCopies()};
["name","age","gender","berth"].forEach(id=>$(id).addEventListener("input",renderCopies));
$("export").onclick=async()=>{const blob=await Promise.resolve({vault: JSON.parse(localStorage.getItem("vault")||"null")});if(!blob.vault)return;const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(blob.vault)],{type:"application/json"}));a.download="passenger-vault-encrypted.json";a.click();URL.revokeObjectURL(a.href)};
$("import").onchange=async e=>{try{const f=e.target.files[0];const blob=JSON.parse(await f.text());profiles=await decrypt(blob,$("passphrase").value);await Promise.resolve(localStorage.setItem("vault", JSON.stringify(blob)));refresh();$("status").textContent="Encrypted backup imported."}catch(err){$("status").textContent="Import failed. Unlock first and check passphrase/backup."}};
