PERSONAL PASSENGER DETAILS HELPER — SETUP

महत्वपूर्ण:
यह केवल passenger profile organizer है। यह IRCTC वेबसाइट/ऐप से interact नहीं करता।
कोई auto-login, auto-fill, CAPTCHA solve, OTP handling, booking submission या payment automation नहीं है।
IRCTC की शर्तों में scripting/Tatkal software प्रतिबंधित हैं। इसलिए IRCTC page पर script चलाने वाला फीचर शामिल नहीं है।

PC पर Chrome Extension:
1. ZIP extract करें।
2. Chrome में chrome://extensions खोलें।
3. Developer mode ON करें।
4. Load unpacked दबाएँ।
5. निकाले गए folder में chrome-extension चुनें।
6. Extension icon खोलें और कम-से-कम 10 अक्षरों का passphrase बनाएँ।
7. Passenger profile सेव करें। अगली बार unlock करके profile load करें और individual Copy buttons से details paste करें।

Android:
1. mobile-app folder को अपने निजी HTTPS static host पर रखें (या आधुनिक browser में local index.html खोलें)।
2. Android browser में page खोलें और menu > Add to Home screen चुनें।
3. यह मोबाइल पर अलग encrypted vault रखता है।
4. PC और phone के बीच profiles ले जाने के लिए Export encrypted backup / Import backup इस्तेमाल करें। एक ही passphrase रखें।

सुरक्षा:
- IRCTC password, OTP, Aadhaar number, payment/card details सेव न करें।
- Passphrase भूलने पर encrypted data recover नहीं किया जा सकता।
- Backup JSON को निजी रखें; सार्वजनिक लिंक/क्लाउड पर न डालें।
- Passenger details paste करने के बाद हर field खुद जाँचें।
